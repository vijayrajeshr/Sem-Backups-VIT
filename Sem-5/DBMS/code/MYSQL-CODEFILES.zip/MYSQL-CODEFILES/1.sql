USE dbms_sem5;

CREATE TABLE student_data(reg_no VARCHAR(10),name VARCHAR(15),branch VARCHAR(5),cgpa FLOAT(2))

DROP TABLE student_data;

INSERT INTO student_data(reg_no,name,branch,cgpa) VALUES
('23BAI10917', 'Catherine','CSE','8.44'),
('23BAI10002', 'Ishita Verma','EEE','9.5'),
('23BAI10003', 'Rajesh Kumar','ECE','8.66'),
('23BAI10004', 'Sneha Iyer','BHI','7.54'),
('23BAI10005', 'Vikram Singh','MECH','7.0'),
('23BAI10400', 'Ananya Pandey','BIO','8.99');

SELECT* FROM student_data;

UPDATE student_data SET cgpa=7.99 WHERE cgpa=7;
TRUNCATE TABLE student_data;

DROP COLUMN S_no;
ALTER TABLE student_data ADD S_no AUTO_INCREMENT;
