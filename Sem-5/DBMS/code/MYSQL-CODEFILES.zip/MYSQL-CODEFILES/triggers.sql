USE dbms_sem5;
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    grade CHAR(2) NOT NULL
);
CREATE TABLE grade_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    old_grade CHAR(2),
    new_grade CHAR(2),
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id)
);
DELIMITER //
CREATE TRIGGER after_grade_update
AFTER UPDATE ON students
FOR EACH ROW
BEGIN
    IF OLD.grade <> NEW.grade THEN
        INSERT INTO grade_log (student_id, old_grade, new_grade)
        VALUES (OLD.id, OLD.grade, NEW.grade);
    END IF;
END;
//
DELIMITER ;
-- Insert sample data
INSERT INTO students (name, age, grade) VALUES ('Alice', 15, 'A');
INSERT INTO students (name, age, grade) VALUES ('Bob', 16, 'B');
-- Update a grade to trigger the log
UPDATE students SET grade = 'A+' WHERE id = 2;
-- Check the log
SELECT * FROM grade_log;
