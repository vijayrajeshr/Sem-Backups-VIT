USE dbms_sem5;

DROP TABLE Proctee_Leave_History;
DROP TABLE Proctee_Proctor_Assignment;
DROP TABLE Proctee;
DROP TABLE Proctor;

CREATE TABLE Proctee (
    Reg_no VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(50),
    Phone_no VARCHAR(10),
    Email VARCHAR(255),
    Program VARCHAR(10),
    Branch VARCHAR(10),
    School VARCHAR(10),
    Resident_info VARCHAR(255)
);

CREATE TABLE Proctor (
    Proctor_ID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50),
    Phone_no VARCHAR(10),
    Email VARCHAR(255),
    Branch VARCHAR(10),
    School VARCHAR(10),
    Resident_info VARCHAR(255)
);

CREATE TABLE Proctee_Proctor_Assignment (
    Reg_no VARCHAR(10),
    Proctor_ID INT,
    PRIMARY KEY (Reg_no, Proctor_ID),
    FOREIGN KEY (Reg_no) REFERENCES Proctee(Reg_no) ON DELETE CASCADE,
    FOREIGN KEY (Proctor_ID) REFERENCES Proctor(Proctor_ID) ON DELETE CASCADE
);

CREATE TABLE Proctee_Leave_History (
    Leave_ID INT AUTO_INCREMENT PRIMARY KEY,
    Reg_no VARCHAR(10),
    Name VARCHAR(50),
    Visiting_Place VARCHAR(100),
    Reason VARCHAR(255),
    Leave_Type VARCHAR(20),
    Leave_From DATE,
    Leave_To DATE,
    Status VARCHAR(20) DEFAULT 'Pending',
    Remarks VARCHAR(255),
    FOREIGN KEY (Reg_no) REFERENCES Proctee(Reg_no) ON DELETE CASCADE
);

INSERT INTO Proctor (Name, Phone_no, Email, Branch, School, Resident_info) VALUES
('Dr. Arjun Rao', '9876543100', 'arjunrao@vitbhopal.ac.in', 'CSE', 'SOE', 'Bangalore, Karnataka'),
('Dr. Meera Iyer', '9876543101', 'meeraiyer@vitbhopal.ac.in', 'ECE', 'SOE', 'Mumbai, Maharashtra'),
('Dr. Vikram Sharma', '9876543102', 'vikramsharma@vitbhopal.ac.in', 'MECH', 'SOE', 'Delhi, India'),
('Dr. Sangeeta Reddy', '9876543103', 'sangeetareddy@vitbhopal.ac.in', 'IT', 'SOE', 'Hyderabad, Telangana');

INSERT INTO Proctee (Reg_no, Name, Phone_no, Email, Program, Branch, School, Resident_info) VALUES
('23BAI1001', 'Aarav Sharma', '9876543201', 'aarav@vitbhopal.ac.in', 'B.Tech', 'CSE', 'SOE', 'Delhi, India'),
('23BAI1002', 'Ishita Verma', '9876543202', 'ishita@vitbhopal.ac.in', 'B.Tech', 'ECE', 'SOE', 'Mumbai, Maharashtra'),
('23BAI1003', 'Rajesh Kumar', '9876543203', 'rajesh@vitbhopal.ac.in', 'B.Tech', 'MECH', 'SOE', 'Chennai, Tamil Nadu'),
('23BAI1004', 'Sneha Iyer', '9876543204', 'sneha@vitbhopal.ac.in', 'B.Tech', 'CIVIL', 'SOE', 'Bangalore, Karnataka'),
('23BAI1005', 'Vikram Singh', '9876543205', 'vikram@vitbhopal.ac.in', 'B.Tech', 'IT', 'SOE', 'Hyderabad, Telangana'),
('23BAI1040', 'Ananya Pandey', '9876543240', 'ananya@vitbhopal.ac.in', 'B.Tech', 'CIVIL', 'SOE', 'Lucknow, Uttar Pradesh');

INSERT INTO Proctee_Proctor_Assignment (Reg_no, Proctor_ID)
SELECT Reg_no, ((ROW_NUMBER() OVER()) - 1) % 4 + 1 
FROM Proctee;

INSERT INTO Proctee_Leave_History (Reg_no, Name, Visiting_Place, Reason, Leave_Type, Leave_From, Leave_To, Status, Remarks) VALUES
('23BAI1001', 'Aarav Sharma', 'New Delhi', 'Family Visit', 'Casual', '2025-03-01', '2025-03-05', 'Approved', 'Approved by Proctor'),
('23BAI1002', 'Ishita Verma', 'Mumbai', 'Medical Emergency', 'Medical', '2025-03-10', '2025-03-15', 'Pending', 'Waiting for approval'),
('23BAI1003', 'Rajesh Kumar', 'Chennai', 'Marriage', 'Casual', '2025-04-01', '2025-04-05', 'Rejected', 'Insufficient leave balance');

UPDATE Proctee SET Phone_no = '9876543299' WHERE Reg_no = '23BAI1001';

DELETE FROM Proctee WHERE Reg_no = '23BAI1040';

SELECT * FROM Proctee_Leave_History WHERE Status = 'Pending';
SELECT P.Proctor_ID, P.Name, COUNT(A.Reg_no) AS Total_Proctees
FROM Proctor P
JOIN Proctee_Proctor_Assignment A ON P.Proctor_ID = A.Proctor_ID
GROUP BY P.Proctor_ID, P.Name;
