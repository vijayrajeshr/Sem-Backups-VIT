------ DBMS ASSIGNMENT 2 ----------
------ 23BAI10917 - - VIJAY RAJESH R --------

-- Numeric Functions
SELECT ABS(-15) AS abs_value, CEIL(4.7) AS ceil_value, FLOOR(4.7) AS floor_value, MOD(17, 5) AS mod_value, POWER(3, 4) AS power_value FROM DUAL;

-- Date Functions
SELECT 
    SYSDATE AS current_date, 
    TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.FF') AS current_timestamp, 
    ADD_MONTHS(SYSDATE, 3) AS add_months_result, 
    NEXT_DAY(SYSDATE, TO_CHAR('FRIDAY', 'DAY', 'NLS_DATE_LANGUAGE=ENGLISH')) AS next_friday 
FROM DUAL;

-- Conversion Functions
SELECT TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') AS date_to_string, TO_NUMBER('1234') + 20 AS string_to_number FROM DUAL;

-- NULL Handling Functions
SELECT NVL(NULL, 'Fallback Value') AS nvl_result, COALESCE(NULL, NULL, '23BAI10917', 'VIJAY RAJESH R') AS coalesce_result FROM DUAL;

-- Mathematical Functions
SELECT ROUND(3.567, 2) AS rounded_value, TRUNC(3.567, 1) AS truncated_value, SIGN(-10) AS sign_value FROM DUAL;

-- Aggregate Functions
SELECT COUNT(*) AS total_rows, MAX(100) AS max_value, MIN(10) AS min_value, SUM(50 + 30) AS sum_value, AVG(20) AS avg_value FROM DUAL;

-- User-Defined Function Example
CREATE OR REPLACE FUNCTION square_value(n IN NUMBER) RETURN NUMBER IS
BEGIN
  RETURN POWER(n, 2);
END;
SELECT square_value(5) AS squared_result FROM DUAL;
