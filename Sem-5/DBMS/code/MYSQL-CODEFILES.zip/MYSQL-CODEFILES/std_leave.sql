USE dbms_sem5;

CREATE TABLE Student (
    Reg_no VARCHAR(10) PRIMARY KEY,
    Std_name VARCHAR(15),
    Phone_no VARCHAR(10),
    Email VARCHAR(15),
    Programm VARCHAR(7),
    Branch VARCHAR(5),
    School VARCHAR(4),
    Resident_info VARCHAR(50)
);
ALTER TABLE Student MODIFY Email VARCHAR(255);
ALTER TABLE proctor MODIFY Email VARCHAR(255);


CREATE TABLE Proctor (
    Proctor_ID INT AUTO_INCREMENT PRIMARY KEY, 
    Prctr_name VARCHAR(15),
    Phone_no VARCHAR(10),
    Email VARCHAR(15),
    Branch VARCHAR(5),
    School VARCHAR(4),
    Resident_info VARCHAR(50)
);

CREATE TABLE Leave_info (
    Leave_id INT AUTO_INCREMENT PRIMARY KEY,
    Reg_no VARCHAR(10),
    Std_name VARCHAR(15),
    Vistng_area VARCHAR(50),
    Reason VARCHAR(50),
    Leave_Typ VARCHAR(10),
    Leave_Date DATE
);

CREATE TABLE Leave_Count (
    Reg_no VARCHAR(10),
    Leave_Month INT,
    Leave_Year INT,
    Leave_Total INT DEFAULT 0,
    PRIMARY KEY (Reg_no, Leave_Month, Leave_Year)
);

CREATE TABLE Student_Proctor_Assignment (
    Reg_no VARCHAR(10),
    Proctor_ID INT,
    PRIMARY KEY (Reg_no, Proctor_ID),
    FOREIGN KEY (Reg_no) REFERENCES Student(Reg_no) ON DELETE CASCADE,
    FOREIGN KEY (Proctor_ID) REFERENCES Proctor(Proctor_ID) ON DELETE CASCADE
);


INSERT INTO Student_Proctor_Assignment (Reg_no, Proctor_ID)
SELECT S.Reg_no, P.Proctor_ID
FROM Student S
JOIN Proctor P 
ON MOD((SELECT COUNT(*) FROM Student WHERE Reg_no <= S.Reg_no), (SELECT COUNT(*) FROM Proctor)) = P.Proctor_ID
LIMIT 10;

/*STUDENT*/
INSERT INTO Student (Reg_no, Std_name, Phone_no, Email, Programm, Branch, School, Resident_info) 
VALUES 
('23BAI10917', 'Aarav Sharma', '9876543210', 'aarav@vitbhopal.ac.in', 'B.Tech', 'CSE', 'SOE', 'Delhi, India'),
('23BAI10918', 'Ishita Verma', '9876543211', 'ishita@vitbhopal.ac.in', 'B.Tech', 'ECE', 'SOE', 'Mumbai, Maharashtra'),
('23BAI10919', 'Rajesh Kumar', '9876543212', 'rajesh@vitbhopal.ac.in', 'B.Tech', 'MECH', 'SOE', 'Chennai, Tamil Nadu'),
('23BAI10920', 'Sneha Iyer', '9876543213', 'sneha@vitbhopal.ac.in', 'B.Tech', 'CIVIL', 'SOE', 'Bangalore, Karnataka'),
('23BAI10921', 'Vikram Singh', '9876543214', 'vikram@vitbhopal.ac.in', 'B.Tech', 'IT', 'SOE', 'Hyderabad, Telangana'),
('23BAI10922', 'Priya Nair', '9876543215', 'priya@vitbhopal.ac.in', 'B.Tech', 'CSE', 'SOE', 'Kochi, Kerala'),
('23BAI10923', 'Arjun Reddy', '9876543216', 'arjun@vitbhopal.ac.in', 'B.Tech', 'ECE', 'SOE', 'Visakhapatnam, Andhra Pradesh'),
('23BAI10924', 'Neha Gupta', '9876543217', 'neha@vitbhopal.ac.in', 'B.Tech', 'CSE', 'SOE', 'Jaipur, Rajasthan'),
('23BAI10925', 'Rohan Mehta', '9876543218', 'rohan@vitbhopal.ac.in', 'B.Tech', 'IT', 'SOE', 'Pune, Maharashtra'),
('23BAI10926', 'Ananya Pandey', '9876543219', 'ananya@vitbhopal.ac.in', 'B.Tech', 'CIVIL', 'SOE', 'Lucknow, Uttar Pradesh');


SELECT*FROM student;
DELETE FROM Student;

DROP TABLE Student;
