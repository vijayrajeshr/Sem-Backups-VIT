CREATE TABLE students_ (
    student_id VARCHAR (10),
    student_name VARCHAR(50),
    city VARCHAR(50),
    course VARCHAR(50),
    backlogs INT,
    exam_fees DECIMAL(10,2),
    grade DECIMAL(3,1),
    semester_completed BOOLEAN,
    debarred BOOLEAN
);
DROP TABLE students_;
INSERT INTO students_(student_id,
    student_name,
    city,
    course,
    backlogs,
    exam_fees,
    grade,
    semester_completed,
    debarred) VALUES ("23BAI10917","Vijay Rajesh R","Krishnagiri,Tamil Nadu","AIML",0,125000,8.87,TRUE,FALSE)

SELECT * FROM students_;

CREATE TABLE instructor (
    instructor_id INT PRIMARY KEY,
    instructor_name VARCHAR(50),
    city VARCHAR(50),
    course VARCHAR(50)
);

SELECT s.student_name, i.instructor_name, s.city 
FROM students_ s
JOIN instructor i ON s.city = i.city;

SELECT student_name, course, backlogs, exam_fees 
FROM students_ 
WHERE debarred = TRUE 
AND grade >= 6.5 
AND semester_completed = TRUE;

SELECT student_name 
FROM students_ 
WHERE (debarred = FALSE OR grade IS NULL);

SELECT s.*, i.* 
FROM students_ s, instructor i;

SELECT s.student_name, i.instructor_name, s.course 
FROM students_ s
JOIN instructor i ON s.course = i.course;
