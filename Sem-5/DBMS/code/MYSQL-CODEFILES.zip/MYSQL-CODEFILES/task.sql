#1----------------------------------------
CREATE USER 'vitB'@'%' IDENTIFIED BY 'vitb123';
GRANT ALL PRIVILEGES ON *.* TO 'vitB'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;

DROP DATABASE student_db

#2----------------------------------------
CREATE DATABASE student_db;
USE student_db;

CREATE TABLE department (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE faculty (
    faculty_id INT PRIMARY KEY,
    faculty_name VARCHAR(100),
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id)
);

CREATE TABLE student (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(100),
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id)
);

CREATE TABLE course (
    course_id INT PRIMARY KEY,
    course_name VARCHAR(100),
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id)
);

#3-------------------------------------------
INSERT INTO department VALUES (1, 'CSE'), (2, 'ECE');

INSERT INTO faculty VALUES
(101, 'Dr. Arjun', 1), (102, 'Dr. Meena', 1), (103, 'Dr. Ravi', 1), (104, 'Dr. Lakshmi', 1), (105, 'Dr. Suresh', 1),
(106, 'Dr. Anjali', 2), (107, 'Dr. Nikhil', 2), (108, 'Dr. Pooja', 2), (109, 'Dr. Manish', 2), (110, 'Dr. Priya', 2);

INSERT INTO student VALUES
(201, 'Aarav', 1), (202, 'Ishaan', 1), (203, 'Kavya', 1), (204, 'Rohit', 1), (205, 'Sneha', 1),
(206, 'Tanvi', 2), (207, 'Tamil', 2), (208, 'Nisha', 2), (209, 'Yash', 2), (210, 'Diya', 2);

#4--------------------------------------------
CREATE TABLE faculty_student_map (
    faculty_id INT,
    student_id INT,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id),
    FOREIGN KEY (student_id) REFERENCES student(student_id)
);

DELIMITER $$

CREATE TRIGGER assign_student
AFTER INSERT ON faculty
FOR EACH ROW
BEGIN
    DECLARE student_assigned INT;

    SELECT student_id INTO student_assigned
    FROM student
    WHERE dept_id = NEW.dept_id
    ORDER BY RAND()
    LIMIT 1;

    INSERT INTO faculty_student_map (faculty_id, student_id)
    VALUES (NEW.faculty_id, student_assigned);
END $$

DELIMITER ;

#5--------------------------------------------
CREATE TABLE attendance (
    student_id INT,
    course_id INT,
    faculty_id INT,
    hours_attended INT,
    FOREIGN KEY (student_id) REFERENCES student(student_id),
    FOREIGN KEY (course_id) REFERENCES course(course_id),
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id)
);

DELIMITER $$

CREATE PROCEDURE get_student_attendance_details (IN in_student_id INT)
BEGIN
    SELECT
        MAX(s.student_name) AS student_name,
        MAX(c.course_name) AS course_name,
        MAX(f.faculty_name) AS faculty_name,
        SUM(a.hours_attended) AS total_hours
    FROM
        attendance a
        JOIN student s ON a.student_id = s.student_id
        JOIN course c ON a.course_id = c.course_id
        JOIN faculty f ON a.faculty_id = f.faculty_id
    WHERE
        a.student_id = in_student_id
    GROUP BY
        a.course_id, a.faculty_id;
END $$

DELIMITER ;

CALL get_student_attendance_details(201);
